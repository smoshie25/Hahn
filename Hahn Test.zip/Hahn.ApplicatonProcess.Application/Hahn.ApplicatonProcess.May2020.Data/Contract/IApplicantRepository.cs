﻿using Hahn.ApplicatonProcess.May2020.Data.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Data.Contract
{
    public interface IApplicantRepository : IBaseRepository<Applicant>
    {

    }
}
