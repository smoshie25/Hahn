﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Data.Entity
{
    public class Applicant
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(50, MinimumLength = 5)]
        public string Name { get; set; }
        [Required]
        [StringLength(50, MinimumLength = 5)]
        public string FamilyName { get; set; }
        [Required]
        [StringLength(50, MinimumLength = 10)]
        public string Address { get; set; }
        [Required]
        public string CountryOfOrigin { get; set; }
        [Required]
        [EmailAddress]
        public string EMailAdress { get; set; }
        [Required]
        [Range(20,60)]
        public int Age { get; set; }
        [Required]
        public bool Hired { get; set; }
    }
}
