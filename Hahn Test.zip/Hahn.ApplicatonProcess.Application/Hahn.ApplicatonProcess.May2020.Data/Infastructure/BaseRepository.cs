﻿using Hahn.ApplicatonProcess.May2020.Data.Contract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Hahn.ApplicatonProcess.May2020.Data.Infastructure
{
    public class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        private readonly IUnitOfWork _unitOfWork;
        protected readonly DbSet<T> dbSet;

        public BaseRepository(IUnitOfWork unitOfWork)
        {
            if (unitOfWork == null) throw new ArgumentNullException("An instance of DbContext is required to use this repository.", "context");
            _unitOfWork = unitOfWork;
            this.dbSet = _unitOfWork.Context.Set<T>();
        }

       

        public virtual void Delete(T entity)
        {
            this.ChangeEntityState(entity, EntityState.Deleted);
        }

        public void Detach(T entity)
        {
            this.ChangeEntityState(entity, EntityState.Detached);
        }


        public virtual IEnumerable<T> GetAll()
        {
            return dbSet.AsEnumerable();
        }

        public T GetById(Guid id)
        {
            return this.dbSet.Find(id);
        }

        public T GetById(int id)
        {
            return this.dbSet.Find(id);
        }

        public virtual T Insert(T entity)
        {
            dbSet.Add(entity);
            this._unitOfWork.Context.SaveChanges();
            return entity;
        }

        public virtual T Update(T entity)
        {
             dbSet.Attach(entity);
            _unitOfWork.Context.Entry(entity).State = EntityState.Modified;
            this._unitOfWork.Context.SaveChanges();
            return entity;
        }

        public void ChangeEntityState(T entity, EntityState state)
        {
            var entry = this._unitOfWork.Context.Entry(entity);
            if (entry.State == EntityState.Detached)
            {

                this.dbSet.Attach(entity);
            }

            if (state == EntityState.Deleted)
            {

                this.dbSet.Remove(entity);
                this._unitOfWork.Context.SaveChanges();
            }


            entry.State = state;
        }
    }
}

