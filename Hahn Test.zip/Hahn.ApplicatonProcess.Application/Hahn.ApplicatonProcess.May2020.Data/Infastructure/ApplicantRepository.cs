﻿using Hahn.ApplicatonProcess.May2020.Data.Contract;
using Hahn.ApplicatonProcess.May2020.Data.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Data.Infastructure
{
    public class ApplicantRepository : BaseRepository<Applicant>, IApplicantRepository
    {
        private readonly IUnitOfWork context;

        public ApplicantRepository(IUnitOfWork _context) : base(_context)
        {
            this.context = _context;
        }



    }
}
