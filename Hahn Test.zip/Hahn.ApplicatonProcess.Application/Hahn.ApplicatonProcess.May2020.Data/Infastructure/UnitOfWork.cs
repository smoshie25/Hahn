﻿using Hahn.ApplicatonProcess.May2020.Data.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Data.Infastructure
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _dbContext;

        public UnitOfWork(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }


        public AppDbContext Context => _dbContext;

        public void Dispose()
        {

        }
    }
}
