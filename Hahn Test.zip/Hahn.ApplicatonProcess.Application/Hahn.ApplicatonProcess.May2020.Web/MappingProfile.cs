﻿using AutoMapper;
using Hahn.ApplicatonProcess.May2020.Data.Entity;
using Hahn.ApplicatonProcess.May2020.Data.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Web
{
    public class MappingProfile : Profile
    {
        public MappingProfile() {
            CreateMap<Applicant, ApplicantForm>();
            CreateMap<ApplicantForm,Applicant>();
        }
    }
}
