﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using AutoMapper;
using Hahn.ApplicatonProcess.May2020.Data.Entity;
using Hahn.ApplicatonProcess.May2020.Data.model;
using Hahn.ApplicatonProcess.May2020.Domain.Busness;
using Hahn.ApplicatonProcess.May2020.Domain.Busness.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hahn.ApplicatonProcess.May2020.Web.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {

        private readonly IApplicantBusinessLogic _applicantBusiness;
        IMapper mapper;
        IHttpClientFactory _clientFactory;
        public ApplicantController(IApplicantBusinessLogic applicantBusinesss, IMapper _mapper, IHttpClientFactory clientFactory)
        {
            this._applicantBusiness = applicantBusinesss;
            this.mapper = _mapper;
            this._clientFactory = clientFactory;
        }

        [HttpPost(Name = nameof(SaveApplicant))]
        public ActionResult SaveApplicant([FromBody] ApplicantForm applicantForm)
        {
            try
            {
                string url = "https://restcountries.eu/rest/v2/name/" + applicantForm.CountryOfOrigin;

                // Web Request with the given url.
                WebRequest request = WebRequest.Create(url);
                request.Credentials = CredentialCache.DefaultCredentials;

                WebResponse response = request.GetResponse();

                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);

                string jsonResponse = null;
                jsonResponse = reader.ReadLine();

                if (jsonResponse != null)
                {
                    Applicant applicant = this._applicantBusiness.Insert(this.mapper.Map<Applicant>(applicantForm));

                    return Created("", this.mapper.Map<ApplicantForm>(applicant));
                }
                else
                {
                    return NotFound("Country not found");
                }
            }
            catch (Exception e) {

                return NotFound("Country not found");
            }
          
        }

        [HttpPut("{Id}",Name = nameof(UpdateApplicant))]
        public ActionResult UpdateApplicant(int Id,[FromBody] ApplicantForm applicantForm)
        {
            try
            {
                string url = "https://restcountries.eu/rest/v2/name/" + applicantForm.CountryOfOrigin;

                // Web Request with the given url.
                WebRequest request = WebRequest.Create(url);
                request.Credentials = CredentialCache.DefaultCredentials;

                WebResponse response = request.GetResponse();

                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);

                string jsonResponse = null;
                jsonResponse = reader.ReadLine();

                if (jsonResponse != null)
                {
                    applicantForm.Id = Id;
                    Applicant applicant = this._applicantBusiness.Update(this.mapper.Map<Applicant>(applicantForm));

                    return Ok("Update successful");
                }
                else
                {
                    return NotFound("Country not found");
                }
            }
            catch (Exception e)
            {

                return NotFound("Country not found");
            }

        }


        [HttpGet("{Id}", Name = nameof(GetApplicantById))]
        public ActionResult<ApplicantForm> GetApplicantById(int Id)
        {
            Applicant applicant = this._applicantBusiness.GetById(Id);

            ApplicantForm appView = this.mapper.Map<ApplicantForm>(applicant);

            if (appView == null) {
                return NotFound("Application not found");
            }

            return appView;
        }

        [HttpDelete("{Id}", Name = nameof(DeleteApplicant))]
        public ActionResult DeleteApplicant(int Id)
        {
            Applicant applicant = this._applicantBusiness.GetById(Id);


            if (applicant == null) {
                return NotFound("Application not found");
            }

            this._applicantBusiness.Delete(applicant);

            return Ok("Delete Successful");
        }
    }
}
