﻿using Hahn.ApplicatonProcess.May2020.Data;
using Hahn.ApplicatonProcess.May2020.Data.Contract;
using Hahn.ApplicatonProcess.May2020.Data.Entity;
using Hahn.ApplicatonProcess.May2020.Data.Infastructure;
using Hahn.ApplicatonProcess.May2020.Domain.Busness.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Domain.Busness
{
    public class ApplicantBusinessLogic : IApplicantBusinessLogic
    {
        private readonly IApplicantRepository applicantRepository;


        public ApplicantBusinessLogic(IApplicantRepository _applicantRepository)
        {
            this.applicantRepository = _applicantRepository;
        }

        public void Delete(Applicant entity)
        {
            this.applicantRepository.Delete(entity);
        }

        public IEnumerable<Applicant> GetAll()
        {
            return this.applicantRepository.GetAll();
        }

        public Applicant GetById(int Id)
        {
            return this.applicantRepository.GetById(Id);
        }

        public Applicant Insert(Applicant entity)
        {
            return this.applicantRepository.Insert(entity);
        }

        public Applicant Update(Applicant entity)
        {
            return this.applicantRepository.Update(entity);
        }
    }
}
