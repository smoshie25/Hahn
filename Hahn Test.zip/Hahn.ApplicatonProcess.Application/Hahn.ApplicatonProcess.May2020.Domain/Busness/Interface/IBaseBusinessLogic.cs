﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Domain.Busness.Interface
{
    public interface IBaseBusinessLogic<T>
    {
        IEnumerable<T> GetAll();

        T GetById(int Id);

        T Insert(T entity);

        T Update(T entity);

        void Delete(T entity);
    }
}
